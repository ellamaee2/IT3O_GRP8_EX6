<!-- footer.php -->
<footer>
    <p>&copy; PAMANTASAN NG LUNGSOD NG MUNTINLUPA</p>
    <p> Group 8  Exercise 6 </p>
    <nav>
        <ul>
            <li><a href="terms.php">Terms & Conditions</a></li>
            <li><a href="privacy.php">Privacy Policy</a></li>
        </ul>
    </nav>
</footer>